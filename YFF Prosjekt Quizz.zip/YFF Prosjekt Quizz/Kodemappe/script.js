const quizData = [
    {
        question: 'What is the capital of France?',
        options: ['Paris', 'London', 'Berlin', 'Rome'],
        answer: 'Paris'
    },
    {
        question: 'What is 2 + 2?',
        options: ['3', '4', '5', '6'],
        answer: '4'
    },
    {
        question: 'Who is the author of "To Kill a Mockingbird"?',
        options: ['Harper Lee', 'Stephen King', 'J.K. Rowling', 'Charles Dickens'],
        answer: 'Harper Lee'
    },
    {
        question: 'Which planet is known as the Red Planet?',
        options: ['Earth', 'Mars', 'Venus', 'Jupiter'],
        answer: 'Mars'
    },
    {
        question: 'What year did the Titanic sink?',
        options: ['1912', '1905', '1921', '1930'],
        answer: '1912'
    }
];

const questionContainer = document.getElementById('question-container');
const answerButtons = document.getElementById('answer-buttons');
const nextButton = document.getElementById('next-button');
const resultDisplay = document.getElementById('result');

let currentQuestionIndex = 0;
let score = 0;

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.classList.add('hide');
    resultDisplay.innerText = '';
    showQuestion(quizData[currentQuestionIndex]);
}

function showQuestion(question) {
    questionContainer.innerText = question.question;
    answerButtons.innerHTML = '';
    question.options.forEach(option => {
        const button = document.createElement('button');
        button.innerText = option;
        button.classList.add('btn');
        button.addEventListener('click', () => selectAnswer(option, question.answer));
        answerButtons.appendChild(button);
    });
}

function selectAnswer(selectedOption, correctAnswer) {
    if (selectedOption === correctAnswer) {
        score++;
        resultDisplay.innerText = 'Correct!';
    } else {
        resultDisplay.innerText = 'Wrong!';
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < quizData.length) {
        showQuestion(quizData[currentQuestionIndex]);
    } else {
        resultDisplay.innerText = `You scored ${score} out of ${quizData.length}`;
        nextButton.classList.remove('hide');
    }
}

nextButton.addEventListener('click', () => startQuiz());

startQuiz();
